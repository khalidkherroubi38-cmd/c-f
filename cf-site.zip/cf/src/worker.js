// Worker C&F : sert le site, vérifie le mot de passe admin, enregistre les données dans KV.
const json = (o, s = 200) =>
  new Response(JSON.stringify(o), { status: s, headers: { "content-type": "application/json", "cache-control": "no-store" } });

async function sha(s) {
  return new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s)));
}
async function okPw(pw, env) {
  if (typeof pw !== "string" || !env.ADMIN_PASSWORD) return false;
  const [a, b] = await Promise.all([sha(pw), sha(env.ADMIN_PASSWORD)]);
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a[i] ^ b[i];
  return d === 0;
}
async function refuse() {
  await new Promise((r) => setTimeout(r, 800));
  return json({ error: "unauthorized" }, 401);
}
async function body(request) {
  try { return await request.json(); } catch { return {}; }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/api/login" && request.method === "POST") {
      const { pw } = await body(request);
      return (await okPw(pw, env)) ? json({ ok: true }) : refuse();
    }

    if (url.pathname === "/api/save" && request.method === "POST") {
      const b = await body(request);
      if (!(await okPw(b.pw, env))) return refuse();
      const d = b.data;
      if (!d || typeof d !== "object" || !Array.isArray(d.cats)) return json({ error: "bad data" }, 400);
      await env.DATA.put("site", JSON.stringify(d));
      return json({ ok: true });
    }

    if (url.pathname === "/") {
      // Page d'accueil : on remplace les données du fichier par celles enregistrées dans KV.
      const res = await env.ASSETS.fetch(new Request(url.origin + "/", { method: "GET" }));
      const h = new Headers(res.headers);
      h.set("cache-control", "no-cache");
      h.delete("etag");
      h.delete("content-length");
      const out = new Response(res.body, { status: res.status, headers: h });
      const saved = await env.DATA.get("site");
      if (!saved || res.status !== 200) return out;
      const safe = saved.replace(/</g, "\\u003c");
      return new HTMLRewriter()
        .on("script#data", { element(el) { el.setInnerContent(safe, { html: true }); } })
        .transform(out);
    }

    return env.ASSETS.fetch(request);
  },
};
